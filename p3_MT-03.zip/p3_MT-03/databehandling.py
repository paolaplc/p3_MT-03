#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Dec  2 07:24:52 2024

@author: MT-03 2024
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt



# File paths
#input_file_path = "data/R7"  
#output_file_path = 'data/data_with_R7.csv'

#input_file_path = "data/Q45 R4_2"  
#output_file_path = 'data/data_with_Q45_R4.csv'

input_file_path = "data/Sandheden"  
output_file_path = 'data/data_with_Sandheden.csv'

#input_file_path = "data/Q100"  
#output_file_path = 'data/data_with_Q100.csv'


# Column identification
column_names = [
    "Cart Position (m)",
    "Pendulum Angle (rad)",
    "Cart Velocity (m/s)",
    "Pendulum Angular Velocity (rad/s)",
    "Control Input (r)",
    "Reference Signal (r)"
]



#Data processing
cleaned_data = []
with open(input_file_path, 'r') as file:
    lines = file.readlines()
    num_lines = len(lines)
    i = 0
    while i < num_lines:
        line = lines[i].strip()
        if line and ',' in line:  # Multi-column rows
            cols = line.split(',')
            # Add the next line 
            i += 1
            if i < num_lines:
                angle_line = lines[i].strip()
                cols.append(angle_line) 
            if len(cols) == len(column_names):
                cleaned_data.append(cols)  
        i += 1   
        
# DataFrame
cleaned_df = pd.DataFrame(cleaned_data, columns=column_names)
cleaned_df = cleaned_df.apply(pd.to_numeric, errors='coerce')

# Sampling time 
sampling_time = 0.00667
cleaned_df['Time (s)'] = [i * sampling_time for i in range(len(cleaned_df))]


# Pendulum
#cleaned_df["Pendulum Angle (rad)"] -= 0.00522
cleaned_df["Pendulum Angle (rad)"] += 0.01577


# Save DataFrame 
cleaned_df.to_csv(output_file_path, index=True)


# Indices for plotting 
start_index = 0
end_index = 2200
df_range = cleaned_df.iloc[start_index:end_index]


# Cart Position
plt.figure(figsize=(10, 6)) 
plt.plot(df_range["Time (s)"], df_range["Cart Position (m)"], label="Cart Position (m)")
plt.xlabel("Time (s)", fontsize=12, labelpad=10) 
plt.ylabel("Cart Position (m)", fontsize=12, labelpad=10)
plt.title("Cart Position Over Time", fontsize=14, pad=15)
plt.legend(fontsize=12, loc="upper right", frameon=True) 
plt.grid(visible=True, which='both', linestyle='--', linewidth=0.5, alpha=0.7) 
plt.tight_layout()
plt.show()

# Pendulum Angle
plt.figure(figsize=(10, 6)) 
plt.plot(df_range["Time (s)"], df_range["Pendulum Angle (rad)"], label="Pendulum Angle (rad)", color='orange')
plt.xlabel("Time (s)", fontsize=12, labelpad=10)  
plt.ylabel("Pendulum Angle (rad)", fontsize=12, labelpad=10)
plt.title("Pendulum Angle Over Time", fontsize=14, pad=15)
plt.legend(fontsize=12, loc="upper right", frameon=True) 
plt.grid(visible=True, which='both', linestyle='--', linewidth=0.5, alpha=0.7)
plt.tight_layout()
plt.show()





