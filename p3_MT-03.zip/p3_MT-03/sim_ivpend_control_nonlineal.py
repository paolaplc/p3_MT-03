#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Nov 26 10:38:40 2024

@author: MT-03 2024
"""


import numpy as np
import matplotlib.pyplot as plt
import control as ctrl
from scipy.integrate import solve_ivp
from tabulate import tabulate

# Parameters
params = {
    "m_c": 6.28,        # (kg)        mass cart
    "m_p": 0.25,        # (kg)        mass pendulum
    "l": 0.333,         # (m)         lenght rod
    "c_max_d": 0.385,   # (m)         carts max displacement
    "g": 9.82,          # (m/s^2)     gravity
    "F_fp": 4.1e-3,     # (N·m)       pendulum coulomb friction
    "alpha": 0.5e-3,    # (N·m·s)     pendulum visous friction
    "F_fc": 3.2,        # (N)         cart coulomb friction
    "r": 0.028,         # (m)         pulley radius
    "k_M": 93.4e-3,     # (N·m/A)     torque constant
    "k": 1,                           #Friction gain
    "i_max_s": 78.9,    # (A)         maximal starting current
    "T_c": 0.420        # (N·m)       maximal continous torque
}

# State-space
A = np.array([
    [0, 0, 1, 0],
    [0, 0, 0, 1],
    [0, (params["m_p"] * params["g"]) / params["m_c"], 
     -params["F_fc"] / params["m_c"], 
     (-params["F_fp"] - params["alpha"]) / (params["m_c"] * params["l"])],
    
    [0, (params["g"] * (params["m_c"] + params["m_p"])) / (params["m_c"] * params["l"]),
     -params["F_fc"] / (params["m_c"] * params["l"]), 
     -((params["F_fp"] + params["alpha"]) * (params["m_c"] + params["m_p"])) / 
     (params["m_p"] * params["m_c"] * params["l"]**2)]
])

B = np.array([
    [0],
    [0],
    [1 / params["m_c"]],
    [1 / (params["m_c"] * params["l"])]
])


# Bryson's Rule 
d_c = 0.385          # Max cart displacement (m)
u_s = 263.18          # Max control force (N)


# Weight matrices
Q = np.diag([
    42/d_c**2,
    0,  
    0,  
    0 
])

R = np.array([[1 / u_s**2]])



# LQR 
K, _, _ = ctrl.lqr(A, B, Q, R)
K = -K 

# Eigenvalues and gain matrix
eigenvalues, _ = np.linalg.eig(A + B @ K)
print("Gain Matrix (K):\n", K)
print("Closed-loop Eigenvalues:\n", eigenvalues)


# Nonlinear dynamics
def pendulum_dynamics_nonlinear(t, z, params, K):
    z1, z2, z3, z4 = z
    u = np.dot(K, z)  
    D = params["m_c"] + params["m_p"] - params["m_p"] * np.cos(z2)**2
    tau_c = np.tanh(params["k"] * z3) * params["F_fc"] 
    tau_p = np.tanh(params["k"] * z4) * params["F_fp"] 
    
    dz1 = z3
    dz2 = z4
    dz3 = ((-tau_c + (-tau_p - params["alpha"] * z4) / params["l"] * np.cos(z2) +
            params["m_p"] * params["g"] * np.sin(z2) * np.cos(z2) - z4**2 * params["m_p"] * params["l"] * np.sin(z2)) / D) + (u / D)
    
    dz4 = (((-tau_c - (tau_p + params["alpha"] * z4) / params["l"] * np.cos(z2) +
             params["m_p"] * params["g"] * np.sin(z2) * np.cos(z2) - z4**2 * params["m_p"] * params["l"] * np.sin(z2)) /
            (D * params["l"]) * np.cos(z2) + params["g"] * np.sin(z2) / params["l"] +
            (-tau_p - params["alpha"] * z4) / (params["m_p"] * params["l"]**2))) + ((np.cos(z2) * u) / (D * params["l"]))
    
    return np.array([float(dz1), float(dz2), float(dz3), float(dz4)])


# Simulation
initial_conditions = [
    [0, -0.1, 0, 0],  
    [0, -0.2, 0, 0], 
    [0, -0.3, 0, 0], 
]
# For Plots
ICs = ['-0.1', '-0.2', '-0.3']


# Time span and points
t_span = (0, 2)

t_eval = np.linspace(*t_span, 997)

trajectories = []
currents = []


for initial_state in initial_conditions:
    sol = solve_ivp(                           
        pendulum_dynamics_nonlinear,
        t_span,
        initial_state,
        args=(params, K),
        t_eval=t_eval,
        method='RK45'
    )
    trajectory = sol.y.T
    u = np.dot(K, trajectory.T).T 
    current = (params["r"] / params["k_M"]) * u 
    trajectories.append(trajectory)
    currents.append(current)
    

# Plots
from matplotlib.backends.backend_pdf import PdfPages

title = "pendulum_simulation"

with PdfPages(f"{title}.pdf") as pdf:
    fig = plt.figure(figsize=(11, 6))

    # Left column 
    ax1 = plt.subplot2grid((6, 4), (0, 0), rowspan=3, colspan=2) 
    ax2 = plt.subplot2grid((6, 4), (3, 0), rowspan=3, colspan=2) 

    # Right column 
    ax3 = plt.subplot2grid((6, 4), (0, 2), rowspan=2, colspan=2) 
    ax4 = plt.subplot2grid((6, 4), (2, 2), rowspan=2, colspan=2) 
    ax5 = plt.subplot2grid((6, 4), (4, 2), rowspan=2, colspan=2)  

    #(z1)
    ax1.set_title("Cart Displacement (m)")
    for idx, traj in enumerate(trajectories):
        ax1.plot(t_eval, traj[:, 0], label=f"{ICs[idx]} rad")
    ax1.axhline(params["c_max_d"], color='r', linestyle='--', label="Max displacement")
    ax1.grid()
    ax1.legend()

    #(i)
    ax2.set_title("Motor Current (i)")
    for idx, current in enumerate(currents):
        ax2.plot(t_eval, current, label=f"{ICs[idx]} rad")
    ax2.axhline(params["i_max_s"], color='r', linestyle='--', label="Max Current")
    ax2.grid()
    ax2.legend()

    # (z2)
    ax3.set_title("Pendulum Angle (rad)")
    for idx, traj in enumerate(trajectories):
        ax3.plot(t_eval, traj[:, 1], label=f"{ICs[idx]} rad")
    ax3.grid()


    # (z3)
    ax4.set_title("Cart Velocity (m/s)")
    for idx, traj in enumerate(trajectories):
        ax4.plot(t_eval, traj[:, 2], label=f"{ICs[idx]} rad")
    ax4.grid()
 

    #(z4)
    ax5.set_title("Angular Velocity (rad/s)")
    for idx, traj in enumerate(trajectories):
        ax5.plot(t_eval, traj[:, 3], label=f"{ICs[idx]} rad")
    ax5.grid()
    ax5.legend()

    plt.tight_layout()
    #pdf.savefig(fig)  

# Print
for idx, (trajectory, current) in enumerate(zip(trajectories, currents)):
    print(tabulate([
        ['Cart Displacement', max(trajectory[:, 0]), min(trajectory[:, 0])],
        ['Pendulum Angle', max(trajectory[:, 1]), min(trajectory[:, 1])],
        ['Cart Velocity', max(trajectory[:, 2]), min(trajectory[:, 2])],
        ['Angular Velocity', max(trajectory[:, 3]), min(trajectory[:, 3])],
        ['Motor Current', max(current), min(current)]
    ], headers=[f"IC {idx + 1}", 'max', 'min']))
    print()

with PdfPages(f"{title}.pdf") as pdf:
        pdf.savefig(fig)






