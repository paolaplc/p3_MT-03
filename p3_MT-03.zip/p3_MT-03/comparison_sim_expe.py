#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Dec  9 00:23:57 2024

@author: MT-03 2024
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp
from sim_ivpend_control_nonlineal import params, K
from databehandling import cleaned_df



# Picking the center
z1_equilibrium = 0.385

def pendulum_dynamics_nonlinear(t, z, params, K):
    z1, z2, z3, z4 = z
    z1_shifted = z1 - z1_equilibrium  

    u = np.dot(K, [z1_shifted, z2, z3, z4]) 
    D = params["m_c"] + params["m_p"] - params["m_p"] * np.cos(z2)**2
    tau_c = np.tanh(params["k"] * z3) * params["F_fc"] 
    tau_p = np.tanh(params["k"] * z4) * params["F_fp"] 
    
    dz1 = z3
    dz2 = z4
    dz3 = ((-tau_c + (-tau_p - params["alpha"] * z4) / params["l"] * np.cos(z2) +
            params["m_p"] * params["g"] * np.sin(z2) * np.cos(z2) - z4**2 * params["m_p"] * params["l"] * np.sin(z2)) / D) + (u / D)
    
    dz4 = (((-tau_c - (tau_p + params["alpha"] * z4) / params["l"] * np.cos(z2) +
             params["m_p"] * params["g"] * np.sin(z2) * np.cos(z2) - z4**2 * params["m_p"] * params["l"] * np.sin(z2)) /
            (D * params["l"]) * np.cos(z2) + params["g"] * np.sin(z2) / params["l"] +
            (-tau_p - params["alpha"] * z4) / (params["m_p"] * params["l"]**2))) + ((np.cos(z2) * u) / (D * params["l"]))
    
    return np.array([float(dz1), float(dz2), float(dz3), float(dz4)])


initial_conditions = [
    [z1_equilibrium, -0.1, 0, 0]
]

t_span = (0, 13)
t_eval = np.linspace(*t_span, 997)

trajectories = []
currents = []

for initial_state in initial_conditions:
    sol = solve_ivp(
        pendulum_dynamics_nonlinear,
        t_span,
        initial_state,
        args=(params, K),
        t_eval=t_eval,
        method='RK45'
    )
    trajectory = sol.y.T
    u = np.dot(K, trajectory.T).T 
    current = (params["r"] / params["k_M"]) * u 
    trajectories.append(trajectory)
    currents.append(current)



start_index = 0
end_index = 1995
df_range = cleaned_df.iloc[start_index:end_index]

# Plot
plt.figure(figsize=(10, 6))
plt.plot(t_eval, trajectories[0][:, 0], label="Simulated Cart Position", linestyle="--", linewidth=2, color="green")
plt.plot(df_range["Time (s)"], df_range["Cart Position (m)"], label="Experimental Cart Position", linewidth=2, color="blue")
plt.xlabel("Time (s)")
plt.ylabel("Cart Position (m)")
plt.title("Cart Position")
plt.legend()
plt.grid()
plt.show()

plt.figure(figsize=(10, 6))
plt.plot(t_eval, trajectories[0][:, 1], label="Simulated Pendulum Angle", linestyle="--", linewidth=2, color="green")
plt.plot(df_range["Time (s)"], df_range["Pendulum Angle (rad)"], label="Experimental Pendulum Angle ", linewidth=2, color="blue")
plt.xlabel("Time (s)")
plt.ylabel("Pendulum Angle (rad)")
plt.title("Pendulum Angle")
plt.legend()
plt.grid()
plt.show()